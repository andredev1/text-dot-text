#!/bin/bash
echo "|1| ";
if(
(
mysql -uroot -proot -e "use dtb_rooms; select fld_occupied from tbl_rooms where fld_number=1";
)>0
)
{
echo " █";
}else
{
echo "\";
}
echo "|2|";
if(
(
mysql -uroot -proot -e "use dtb_rooms; select fld_occupied from tbl_rooms where fld_number=1";
)>0
)
{
echo " █";
}else
{
echo "\";
}
echo "type bed number";
read bedNumber;
