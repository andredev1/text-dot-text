 #!/bin/bash
echo "|1|      █"; 
echo "|2|      \";
echo "type bed number";
read bedNumber;
