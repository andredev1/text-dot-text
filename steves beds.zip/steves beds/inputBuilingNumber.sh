 #!/bin/bash
echo "|1|";
echo "|2|";
echo "|3| ";
echo "|4| ";
echo "|4| ";
echo "|5| ";
echo "type building number";
read buildingNumber;
